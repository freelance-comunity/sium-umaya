<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Asistencia_has_nomina extends Model
{
    protected $table = "asistencia_has_nomina";
}
