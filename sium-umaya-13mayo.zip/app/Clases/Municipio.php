<?php
/**
 * Created by PhpStorm.
 * User: osorio
 * Date: 3/07/16
 * Time: 08:14 AM
 */

namespace app\Clases;


class Municipio {
    private $id;
    private $id_estado;
    private $nombreMunicipio;
}