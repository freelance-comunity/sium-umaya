<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoBaja extends Model
{
    //
    protected $table = "tipo_bajas";
	public $timestamps = false;
}
