<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AsignacionClases extends Model
{
    //
    protected $table = "asignacion_clase";
}
