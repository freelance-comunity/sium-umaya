<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoHorarios extends Model
{
    //
    protected $table = "tipo_horario";
	public $timestamps = false;
}
