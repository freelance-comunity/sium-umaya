<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Descuentos_has_Nomina extends Model
{
    //
    protected $table = "descuentos_has_nomina";
}
