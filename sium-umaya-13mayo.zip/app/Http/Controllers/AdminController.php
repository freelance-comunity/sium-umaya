<?php

namespace App\Http\Controllers;

use App\User;
use App\Clases\Empleados;
use App\TipoBaja;

class AdminController extends Controller {
	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct() {
		$this->middleware('super');
	}

	public function index() {
		return view('admin/index');
	}

	public function personal() {
		$empleados = new Empleados();
		$tipoBajas = TipoBaja::all();
		return view('admin/personal', ['empleados' => $empleados->getEmpleados(), 'tipos' => $tipoBajas]);
	}
}
