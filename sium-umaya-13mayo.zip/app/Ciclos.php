<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ciclos extends Model
{
    //
    protected $table = "ciclos";
    public $timestamps = false;
}
