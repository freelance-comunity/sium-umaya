<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Salones extends Model
{
    //
	protected $table = "salon";
}
