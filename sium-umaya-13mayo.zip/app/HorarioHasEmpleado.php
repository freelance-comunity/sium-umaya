<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class HorarioHasEmpleado extends Model
{
    //
    protected $table = "asignacion_horario";
}
