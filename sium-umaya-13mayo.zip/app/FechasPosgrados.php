<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FechasPosgrados extends Model
{
	protected $table = "fechas_posgrado";
	public $timestamps = false;
}
