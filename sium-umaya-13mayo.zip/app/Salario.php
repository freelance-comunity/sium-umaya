<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Salario extends Model
{
    //
    protected $table = "salario";
}
