<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalarioHasCargo extends Model
{
    //
    protected $table = "many_salario_has_many_cargo";
}
