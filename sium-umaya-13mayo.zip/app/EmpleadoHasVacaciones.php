<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EmpleadoHasVacaciones extends Model
{
    //
    protected $table = "empleado_has_vacaciones";
}
