<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UsuarioPrivilegios extends Model
{
    //
    protected $table = "many_usuario_has_many_privilegios";
}
