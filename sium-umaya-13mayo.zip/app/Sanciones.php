<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sanciones extends Model
{
    //
    protected $table = "sanciones";
}
