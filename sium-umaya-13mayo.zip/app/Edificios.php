<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Edificios extends Model
{
    //
	protected $table = "edificio";
}
