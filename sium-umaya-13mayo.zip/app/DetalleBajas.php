<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetalleBajas extends Model
{
    //
    protected $table = "detalle_bajas";
	public $timestamps = false;
}
