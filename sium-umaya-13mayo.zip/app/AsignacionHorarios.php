<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AsignacionHorarios extends Model
{
    //
    protected $table = "asignacion_horario";
}
