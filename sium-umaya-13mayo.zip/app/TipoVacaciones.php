<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TipoVacaciones extends Model
{
    //
    protected $table = "tipo_vacaciones";
}
